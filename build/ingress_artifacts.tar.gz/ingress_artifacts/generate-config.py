#!/usr/bin/env python3
"""
Generate nginx configuration from template based on command line arguments
"""
import argparse
import sys
from jinja2 import Template


def parse_routes(routes_string):
    """
    Parse the routes string into a list of dictionaries
    Format: location/host:port,location/host:port,...
    """
    routes = []
    default_route = None

    if not routes_string:
        return routes, default_route

    route_pairs = routes_string.split(",")

    for pair in route_pairs:
        pair = pair.strip()
        if not pair:
            continue

        # Find the last slash to split location from host:port
        last_slash_idx = pair.rfind("/")
        if last_slash_idx == -1:
            print(
                f"Error: Invalid route format '{pair}'. Expected format: location/host:port",
                file=sys.stderr,
            )
            sys.exit(1)

        location = pair[:last_slash_idx]
        host_port = pair[last_slash_idx + 1 :]

        if ":" not in host_port:
            print(
                f"Error: Invalid host:port format '{host_port}'. Expected format: host:port",
                file=sys.stderr,
            )
            sys.exit(1)

        host, port = host_port.split(":", 1)

        try:
            port = int(port)
        except ValueError:
            print(
                f"Error: Invalid port number '{port}'. Must be an integer.",
                file=sys.stderr,
            )
            sys.exit(1)

        route_info = {"location": location, "host": host, "port": port}

        if location == "default":
            default_route = route_info
        else:
            routes.append(route_info)

    return routes, default_route


def main():
    parser = argparse.ArgumentParser(
        description="Generate nginx configuration from template"
    )
    parser.add_argument(
        "--app_port",
        type=int,
        required=True,
        help="Port that the ingress service will expose externally",
    )
    parser.add_argument(
        "--routes",
        type=str,
        required=True,
        help="Comma-separated list of location/host:port pairs",
    )
    parser.add_argument(
        "--hostname",
        type=str,
        default="_",
        help="Server hostname for nginx configuration (default: _)",
    )
    parser.add_argument(
        "--template",
        type=str,
        default="/app/templates/nginx-template.j2",
        help="Path to the Jinja2 template file",
    )
    parser.add_argument(
        "--output",
        type=str,
        default="/etc/nginx/nginx.conf",
        help="Output path for the generated nginx configuration",
    )

    args = parser.parse_args()

    # Parse routes
    routes, default_route = parse_routes(args.routes)

    if not default_route:
        print(
            "Error: No 'default' route specified. Please include a 'default/host:port' entry.",
            file=sys.stderr,
        )
        sys.exit(1)

    # Load template
    try:
        with open(args.template, "r") as f:
            template_content = f.read()
    except FileNotFoundError:
        print(f"Error: Template file '{args.template}' not found.", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error reading template file: {e}", file=sys.stderr)
        sys.exit(1)

    # Render template
    template = Template(template_content)

    # Create unique upstream names for each unique host:port combination
    upstreams = {}
    for route in routes + [default_route]:
        upstream_key = f"{route['host']}:{route['port']}"
        if upstream_key not in upstreams:
            # Create a safe upstream name
            upstream_name = (
                f"{route['host'].replace('-', '_').replace('.', '_')}_{route['port']}"
            )
            upstreams[upstream_key] = {
                "name": upstream_name,
                "host": route["host"],
                "port": route["port"],
            }

    # Add upstream info to routes
    for route in routes:
        upstream_key = f"{route['host']}:{route['port']}"
        route["upstream"] = upstreams[upstream_key]["name"]

    default_upstream_key = f"{default_route['host']}:{default_route['port']}"
    default_route["upstream"] = upstreams[default_upstream_key]["name"]

    try:
        rendered_config = template.render(
            app_port=args.app_port,
            hostname=args.hostname,
            routes=routes,
            default_route=default_route,
            upstreams=list(upstreams.values()),
        )
    except Exception as e:
        print(f"Error rendering template: {e}", file=sys.stderr)
        sys.exit(1)

    # Write output
    try:
        with open(args.output, "w") as f:
            f.write(rendered_config)
        print(f"Successfully generated nginx configuration at {args.output}")
    except Exception as e:
        print(f"Error writing output file: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
