#!/bin/bash
set -e

# Default values
APP_PORT=""
ROUTES=""
HOSTNAME="_"

# Parse command line arguments
while [[ $# -gt 0 ]]; do
  case $1 in
    --app_port)
      APP_PORT="$2"
      shift 2
      ;;
    --routes)
      ROUTES="$2"
      shift 2
      ;;
    --hostname)
      HOSTNAME="$2"
      shift 2
      ;;
    *)
      # Pass through any other arguments to the final command
      break
      ;;
  esac
done

# Validate required parameters
if [ -z "$APP_PORT" ]; then
    echo "Error: --app_port is required"
    echo "Usage: docker run ... --app_port <port> --routes <routes> [--hostname <hostname>] [nginx args...]"
    exit 1
fi

if [ -z "$ROUTES" ]; then
    echo "Error: --routes is required"
    echo "Usage: docker run ... --app_port <port> --routes <routes> [--hostname <hostname>] [nginx args...]"
    exit 1
fi

echo "Generating nginx configuration..."
echo "App port: $APP_PORT"
echo "Routes: $ROUTES"
echo "Hostname: $HOSTNAME"

# Generate the nginx configuration
python3 /app/scripts/generate-config.py \
    --app_port "$APP_PORT" \
    --routes "$ROUTES" \
    --hostname "$HOSTNAME"

if [ $? -ne 0 ]; then
    echo "Failed to generate nginx configuration"
    exit 1
fi

echo "Configuration generated successfully"

# Extract unique hostnames from routes and wait for DNS resolution
# This is needed when upstream containers may not be available at startup (e.g., in test environments)
HOSTS=$(echo "$ROUTES" | tr ',' '\n' | sed 's#.*/#/#' | sed 's#/\([^:]*\):.*#\1#' | sort -u)
for HOST in $HOSTS; do
    if [ "$HOST" != "localhost" ] && [ "$HOST" != "127.0.0.1" ]; then
        echo "Waiting for DNS resolution of $HOST..."
        MAX_RETRIES=30
        RETRY_COUNT=0
        while [ $RETRY_COUNT -lt $MAX_RETRIES ]; do
            if getent hosts "$HOST" > /dev/null 2>&1; then
                echo "DNS resolved for $HOST"
                break
            fi
            RETRY_COUNT=$((RETRY_COUNT + 1))
            if [ $RETRY_COUNT -eq $MAX_RETRIES ]; then
                echo "Warning: Could not resolve $HOST after $MAX_RETRIES attempts. Continuing anyway..."
            fi
            sleep 1
        done
    fi
done

echo "Starting nginx with arguments: $@"

# Execute the command (typically nginx)
# If no arguments remain, default to nginx startup
if [ $# -eq 0 ]; then
    exec nginx -g "daemon off;"
else
    exec "$@"
fi